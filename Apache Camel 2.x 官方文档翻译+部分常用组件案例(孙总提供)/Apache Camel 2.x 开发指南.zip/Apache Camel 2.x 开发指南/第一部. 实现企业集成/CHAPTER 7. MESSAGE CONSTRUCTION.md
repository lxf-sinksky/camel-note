# CHAPTER 7. MESSAGE CONSTRUCTION
*KarezFlow 产品组
整理：孙勇
版本：0.1*