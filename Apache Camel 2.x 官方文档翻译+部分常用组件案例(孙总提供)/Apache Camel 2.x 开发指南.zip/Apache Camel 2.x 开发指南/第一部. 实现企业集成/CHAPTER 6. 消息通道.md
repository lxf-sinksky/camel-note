# CHAPTER 6. 消息通道
*KarezFlow 产品组
整理：孙勇
版本：0.1*