# CHAPTER 3. 企业集成模式介绍
*KarezFlow 产品组
编写：孙勇
版本：1.0*


## OVERVIEW OF THE PATTERNS

### 消息系统

### 消息通道
一个消息通道是一个基础组件，用于一个消息系统中参与者之间的连接。

### 消息结构

